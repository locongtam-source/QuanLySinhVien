package quanlysinhvien;

import java.sql.Connection;
import java.sql.DriverManager;

public class ketnoi {

    public static Connection getConnection() {
        Connection conn = null;

        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");

            String url = "jdbc:sqlserver://localhost:1433;"
                    + "databaseName=QuanLySinhVien;"
                    + "encrypt=true;"
                    + "trustServerCertificate=true";

            conn = DriverManager.getConnection(url, "mosss35", "3025124838");

            System.out.println("Kết nối thành công!");

        } catch (Exception e) {
            e.printStackTrace();
        }

        return conn;
    }
}